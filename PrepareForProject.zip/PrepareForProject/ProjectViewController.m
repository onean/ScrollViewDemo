//
//  ProjectViewController.m
//  PrepareForProject
//
//  Created by FaceUI on 13-5-4.
//  Copyright (c) 2013年 faceui. All rights reserved.
//

#import "ProjectViewController.h"

@interface ProjectViewController ()

@end

@implementation ProjectViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated
{
    if (![[NSUserDefaults standardUserDefaults] boolForKey:@"exist_file"]) {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"information" ofType:@"plist"];
        NSDictionary *dic1 = [NSDictionary dictionaryWithContentsOfFile:path];
        [RecordDataForPlist writeDataFromPlistWithName:@"information.plist" andContent:dic1];
        
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"exist_file"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    
    NSDictionary *dic = [RecordDataForPlist readDataFromPlistWithName:@"information.plist"];
    NSMutableArray * contentArray = [[[NSMutableArray alloc]init] autorelease];
    NSMutableArray * backgroundArray = [[[NSMutableArray alloc]init] autorelease];
    NSMutableArray * titleArray =[[[NSMutableArray alloc]init] autorelease];
    NSArray * infoArray = [dic objectForKey:@"info"];
    
    for (int i = 0; i < infoArray.count ; i++) {
        CustomPageScrollView * pageScrollView = [[CustomPageScrollView alloc]initWithFrame:CGRectMake(0, 0, [[UIScreen mainScreen] bounds].size.width, [[UIScreen mainScreen] bounds].size.height-20) withDicInfo:[infoArray objectAtIndex:i]];
        [backgroundArray addObject:[[infoArray objectAtIndex:i] objectForKey:@"background"]];
        [titleArray addObject:[[infoArray objectAtIndex:i] objectForKey:@"title"]];
        [contentArray addObject:pageScrollView];
        [pageScrollView release];
    }
    
    CustomScrollView * customScrollView = [[CustomScrollView alloc]initWithFrame:CGRectMake(0, 0, 320, [[UIScreen mainScreen] bounds].size.height-20) andPageSize:CGSizeMake(320, [[UIScreen mainScreen] bounds].size.height-20) andContentArray:contentArray andBackgroundArray:backgroundArray andTitleArray:titleArray];
    [self.view addSubview:customScrollView];
    
    
    [customScrollView release];
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
    // detailview 
//    for (UIView * v in self.view.window.subviews) {
//        if (v.tag == 30001) {
//            
//        }
//    }
    
}

@end
