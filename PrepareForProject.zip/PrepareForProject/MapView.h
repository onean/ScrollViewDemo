//
//  MapViewController.h
//  Miller
//
//  Created by kadir pekel on 2/7/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
#import "RegexKitLite.h"
#import "Place.h"
#import "PlaceMark.h"
#import "MyJSONKit.h"

#define REQUEST_TIME_OUT @"TIME_OUT"
#define ADD_ROUTE @"ADD_ROUTES"


@interface MapView : UIView<MKMapViewDelegate,NSURLConnectionDataDelegate> {

	MKMapView* mapView;
	UIImageView* routeView;
	NSMutableData * receiveData;
    
    NSArray * routes;
    
    
    
    //version 2
    NSURLConnection *connection;
//	NSMutableArray* routes;
    
    
//	UIColor* lineColor;

}

//@property (nonatomic, retain) UIColor* lineColor;
@property (nonatomic, retain) MKMapView* mapView;
@property (nonatomic, retain) CLLocation *currentLocation;
-(void) showRouteFrom: (Place*) f to:(Place*) t;
-(void) cancelConnect;
@end
