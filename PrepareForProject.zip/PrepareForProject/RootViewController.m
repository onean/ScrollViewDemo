//
//  RootViewController.m
//  PrepareForProject
//
//  Created by FaceUI on 13-5-2.
//  Copyright (c) 2013年 faceui. All rights reserved.
//

#import "RootViewController.h"
#import "CustomPageScrollView.h"
#import "RecordDataForPlist.h"
@interface RootViewController ()

@end

@implementation RootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        NSString *path = [[NSBundle mainBundle] pathForResource:@"information" ofType:@"plist"];
        NSDictionary *dic1 = [NSDictionary dictionaryWithContentsOfFile:path];
        [RecordDataForPlist writeDataFromPlistWithName:@"information.plist" andContent:dic1];
        
        NSDictionary *dic = [RecordDataForPlist readDataFromPlistWithName:@"information.plist"];
        
        NSArray *array = [dic objectForKey:@"info"];
        
        for (int i = 0; i < array.count ; i++) {
            CustomPageScrollView * pageScrollView = [[CustomPageScrollView alloc]initWithFrame:CGRectMake(0, 0, [[UIScreen mainScreen] bounds].size.width, [[UIScreen mainScreen] bounds].size.height-20) withDicInfo:[array objectAtIndex:i]];
            [self.view addSubview:pageScrollView];
            [pageScrollView release];
        }
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
