#import "MyJSONKit.h"
#import "JSONKit.h"
@interface MyJSONKit ()
/*
 @-method        obtainDictionaryFromString:andEncoding:
 @-abstract      依据给定的Joson字符串和编码方式进行json解码
 @-discussion
 @-param         aString      传入的字符串
 @-result        生成字典
 */
+ (NSMutableDictionary *)obtainDictionaryFromString:(NSMutableString *)aString;

/*
 @-method        obtainArrayFromString:andEncoding:
 @-abstract      依据给定的Joson字符串和编码方式进行json解码
 @-discussion
 @-param         aString      传入的字符串
 @-result        生成字典数组
 */
+ (NSMutableArray *)obtainArrayFromString:(NSMutableString *)aString;
@end
@implementation MyJSONKit
+ (id)obtainParseFromData:(NSMutableData *)aData andEncoding:(NSStringEncoding)aEncoding 
{
    NSMutableString *jsonStr = [[NSMutableString alloc] initWithData:aData encoding:aEncoding];
    if ([jsonStr hasPrefix:@"{"]) {
        return [MyJSONKit obtainDictionaryFromString:jsonStr];
    }
    return [MyJSONKit obtainArrayFromString:jsonStr];
}
+ (NSMutableDictionary *)obtainDictionaryFromString:(NSMutableString *)aString
{
    NSRange range = [aString rangeOfString:@"{"];
    NSRange delRange;
    delRange.location = 0;
    if (range.length == 0) {
        delRange.length = 0;
    }
    else
    {
        delRange.length = range.location;
    }
    [aString deleteCharactersInRange:delRange];
    return [aString mutableObjectFromJSONString];
}
+ (NSMutableArray *)obtainArrayFromString:(NSMutableString *)aString
{
    NSRange range = [aString rangeOfString:@"["];
    NSRange delRange;
    delRange.location = 0;
    if (range.length == 0) {
        delRange.length = 0;
    }
    else
    {
        delRange.length = range.location;
    }
    [aString deleteCharactersInRange:delRange];
    return [aString mutableObjectFromJSONString];
}
@end
