//
//  CustomPageScrollView.m
//  PrepareForProject
//
//  Created by FaceUI on 13-5-3.
//  Copyright (c) 2013年 faceui. All rights reserved.
//

#import "CustomPageScrollView.h"
#import <QuartzCore/QuartzCore.h>
#import "PlayAudioButton.h"
#import "MapView.h"
@implementation CustomPageScrollView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
//        [self set]
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame withDicInfo:(NSDictionary *)info
{
    self = [self initWithFrame:frame];
    currentFrame = frame;
    self.delegate = self;
    self.scrollEnabled = YES;
    self.backgroundColor = [UIColor clearColor];
    [self setShowsHorizontalScrollIndicator:NO];
    [self setShowsVerticalScrollIndicator:NO];
    infoDic = [info retain] ;
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receiveNotification:) name:ADD_ROUTE object:nil];
    
    //show one line 
//    int currentHeight = [[UIScreen mainScreen] bounds].size.height - 175 + 89.5;
    //hide all
    int currentHeight = [[UIScreen mainScreen] bounds].size.height;
    
    UIView * audioView = [[UIView alloc]initWithFrame:CGRectMake(7.5,currentHeight, 55, 55)];
    audioView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"home_bgo.png"]];
    
    NSArray *images = [NSArray arrayWithObjects:[UIImage imageNamed:@"home_speaker_0.png"],[UIImage imageNamed:@"home_speaker_1.png"],[UIImage imageNamed:@"home_speaker_2.png"], nil];
    
    NSString *path = [[NSBundle mainBundle] pathForResource:@"ring" ofType:@"mp3"];
    UIView * playView = [[PlayAudioButton alloc]initWithFrame:CGRectMake(12.5, 12.5, 27.5, 27.5) andButtonImage:[UIImage imageNamed:@"home_speaker_2.png"] andSelectedImages:images audioPath:path];
 
    
    [audioView addSubview:playView];
    //modify account
    [playView release];
    
    [self addSubview:audioView];
    [audioView release];
    UITextView *abstractTextView = [[UITextView alloc]initWithFrame:CGRectMake(70, currentHeight, 241.5, 55)];
    abstractTextView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"home_bgt.png"]];
    abstractTextView.textColor = [UIColor whiteColor];
    [abstractTextView setEditable:NO];
    abstractTextView.font = [UIFont systemFontOfSize:12];
    abstractTextView.text = [NSString stringWithFormat:@"  %@",[info objectForKey:@"abstract"]];
    [self addSubview:abstractTextView];
    [abstractTextView release];
    
    currentHeight += 80;
    
    
    NSArray * eatArray = [info objectForKey:@"eating"];
    int line = 0;
    int k = 0;
    
    
    
    
    
    // using code
    if (eatArray.count != 0) {
        for (int i = 0; i < eatArray.count + 1; i++) {
            if (line == 0 && k == 0) {
                UIView *foodTitle = [[CustomButton initWithFrame:CGRectMake(7.5,currentHeight, 55, 55) backgroundImage:[UIImage imageNamed:@"home_bgo.png"] andSubImage:[UIImage imageNamed:@"home_food.png"]] retain];
                [self addSubview:foodTitle];
                [foodTitle release];
            }else
            {
                UIView *view = [[CustomButton initWithFrame:CGRectMake(7.5+ k*62.5,currentHeight, 55, 55) backgroundImage:[UIImage imageNamed:@"home_bgs.png"] andButtonLabel:[[eatArray objectAtIndex:i-1] objectForKey:@"item_title"] target:self selector:@selector(checkTheDetail:)] retain];
                view.tag = 10000 + i - 1;
                [self addSubview:view];
                [view release];
                
            }
            k++;
            if (k == 5) {
                k=0;
                line++;
                currentHeight += 62.5;
            }else if(i == eatArray.count)
            {
                currentHeight += 62.5;
            }
            
        }
    }
    
    
    currentHeight += 10;
    
    
    NSArray * playArray = [info objectForKey:@"playing"];
    
 //using code
  
    if (playArray.count != 0) {
        line = 0;
        k = 0;
        for (int i = 0; i < eatArray.count + 1; i++) {
            if (line == 0 && k == 0) {
                UIView *foodTitle = [[CustomButton initWithFrame:CGRectMake(7.5,currentHeight, 55, 55) backgroundImage:[UIImage imageNamed:@"home_bgo.png"] andSubImage:[UIImage imageNamed:@"home_play.png"]] retain];
                [self addSubview:foodTitle];
                [foodTitle release];
            }else
            {
                UIView *view = [[CustomButton initWithFrame:CGRectMake(7.5+ k*62.5,currentHeight, 55, 55) backgroundImage:[UIImage imageNamed:@"home_bgs.png"] andButtonLabel:[[playArray objectAtIndex:i-1] objectForKey:@"item_title"] target:self selector:@selector(checkTheDetail:)] retain];
                view.tag = 20000 + i - 1;
                [self addSubview:view];
                [view release];
                
            }
            k++;
            if (k == 5) {
                k=0;
                line++;
                currentHeight += 62.5;
            }else if(i == playArray.count)
            {
                currentHeight += 62.5;
            }
            
        }
    }
    
    if ([[UIScreen mainScreen] bounds].size.height == 480) {
        currentHeight += 30;
    }else
    {
        currentHeight += 50;
    }
    
    self.contentSize = CGSizeMake(320, currentHeight);
    
    return self;
}

-(void)checkTheDetail:(id)sender
{
    

    UIButton * b = sender;
    CustomDetailPageView *detailView = nil;
    
    if ([b superview].tag >= 20000 ) {
        NSDictionary * dic = [[infoDic objectForKey:@"playing"] objectAtIndex:[b superview].tag - 20000];
        detailView = [[CustomDetailPageView alloc]initWithTargetLocation:CLLocationCoordinate2DMake([[dic objectForKey:@"location_latitude"] doubleValue], [[dic objectForKey:@"location_longitude"] doubleValue]) andTitle:[dic objectForKey:@"item_title"] andDetail:[dic objectForKey:@"detail"] andBackImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@",[dic objectForKey:@"item_image"]]]];
        
    }else if([b superview].tag >= 10000 )
    {
        NSDictionary * dic = [[infoDic objectForKey:@"eating"] objectAtIndex:[b superview].tag - 10000];
        detailView = [[CustomDetailPageView alloc]initWithTargetLocation:CLLocationCoordinate2DMake([[dic objectForKey:@"location_latitude"] doubleValue], [[dic objectForKey:@"location_longitude"] doubleValue]) andTitle:[dic objectForKey:@"item_title"] andDetail:[dic objectForKey:@"detail"] andBackImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@",[dic objectForKey:@"item_image"]]]];
    }
    [self.superview.window addSubview:detailView];
    [detailView release];

    detailView.tag = 30001;
    
    
//    CABasicAnimation *animation1=[CABasicAnimation animationWithKeyPath:@"bounds.size"];
//    
//    layer.backgroundColor=[[UIColor grayColor]colorWithAlphaComponent:0.3].CGColor;
//    
//    [animation1 setFromValue:[NSValue valueWithCGSize:CGSizeMake(2, 2)]];
//    
//    [animation1 setToValue:[NSValue valueWithCGSize:currentFrame.size]];
//    
//    [animation1 setDuration:0.3];
//    
//    [animation1 setValue:@"缩小" forKey:@"animationID"];
//    
//    [layer addAnimation:animation1 forKey:@"image-bounds.size"];    
    
    
    CATransition *animation = [CATransition animation];
    animation.duration = 1.0;
    animation.timingFunction = UIViewAnimationCurveEaseInOut;
    animation.type = kCATransitionFade;
    [self.window.layer addAnimation:animation forKey:@"animation"];
    
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.tag = 30002;
    button.frame = CGRectMake(280, 20, 40, 40);
    [button setImage:[UIImage imageNamed:@"sub_X.png"] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
    [self.window addSubview:button];
}

-(void)receiveNotification:(id)sender
{
    //按钮无效接受到通知后按钮生效
    for (UIView * v in self.window.subviews) {
        if (v.tag == 30002) {
            [(UIButton *)v setEnabled:YES];
        }
    }

    //收到通知后添加按钮
//    int i = 0;
//    for (UIView * v in self.window.subviews) {
//        if (v.tag == 30002) {
//            i = 1;
//            break;
//        }
//    }
//    if (i == 0) {
//        UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
//        button.tag = 30002;
//        button.frame = CGRectMake(280, 20, 40, 40);
//        [button setImage:[UIImage imageNamed:@"sub_X.png"] forState:UIControlStateNormal];
//        [button addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
//        [self.window addSubview:button];
//    }
}

-(void)cancel:(id)sender
{
    [sender removeFromSuperview];
    for (UIView * v in self.window.subviews) {
        if (v.tag == 30001) {
            [v removeFromSuperview];
            v = nil;
        }
    }
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
