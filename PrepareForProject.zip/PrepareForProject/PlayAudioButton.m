//
//  PlayAudioButton.m
//  PrepareForProject
//
//  Created by FaceUI on 13-5-6.
//  Copyright (c) 2013年 faceui. All rights reserved.
//

#import "PlayAudioButton.h"

@implementation PlayAudioButton

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


-(id)initWithFrame:(CGRect)frame andButtonImage:(UIImage *)image andSelectedImages:(NSArray *)images  audioPath:(NSString *)path
{
    self = [self initWithFrame:frame];
    backgroundImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
    backgroundImageView.image = image;
    
    selfImage = image;
    
    UIButton *audioButton = [UIButton buttonWithType:UIButtonTypeCustom];
    audioButton.backgroundColor = [UIColor clearColor];
    audioButton.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
    [audioButton addTarget:self action:@selector(play:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:audioButton];
    
    NSURL *audioUrl = [NSURL fileURLWithPath:path];
    player = [[AVAudioPlayer alloc]initWithContentsOfURL:audioUrl error:nil];
    [player prepareToPlay];
    [backgroundImageView setAnimationDuration:1];
    playingAnimation = [images retain];
    
    
    [self addSubview:backgroundImageView];
    
    return self;
}

-(void)play:(id)sender
{
//    timer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(timer:) userInfo:timer repeats:YES];
    if (!player.isPlaying) {
        timer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(timer:) userInfo:timer repeats:YES];
//        [timer fire];
        [player play];
        [backgroundImageView setAnimationImages:playingAnimation];
        [backgroundImageView startAnimating];
    }else
    {
        [player stop];
        player.currentTime = 0;
        [timer invalidate];
        timer = nil;
        [backgroundImageView stopAnimating];
        backgroundImageView.image = selfImage;
    }
}

-(void)timer:(id)sender
{
    if (!player.isPlaying) {
        [(NSTimer *)sender invalidate];
        [backgroundImageView stopAnimating];
        backgroundImageView.image = selfImage;
        if (timer != nil) {
            [timer invalidate];
            timer = nil;
        }
    }
}

-(void)dealloc
{
    [super dealloc];
    [backgroundImageView release];
    [player release];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
