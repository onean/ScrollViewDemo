//
//  PlayAudioButton.h
//  PrepareForProject
//
//  Created by FaceUI on 13-5-6.
//  Copyright (c) 2013年 faceui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
@interface PlayAudioButton : UIView
{
    UIImageView * backgroundImageView;
    AVAudioPlayer *player;
    NSArray * playingAnimation;
    UIImage *selfImage;
    NSTimer *timer;
}
-(id)initWithFrame:(CGRect)frame andButtonImage:(UIImage *)image andSelectedImages:(NSArray *)images audioPath:(NSString *)path;
@end