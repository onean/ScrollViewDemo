//
//  CustomScrollView.h
//  ScrollViewTestDemo
//
//  Created by FaceUI on 13-4-23.
//  Copyright (c) 2013年 faceui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIImage+vImage.h"
#import "DKLiveBlurView.h"
@interface CustomScrollView : UIScrollView<UIScrollViewDelegate>
{
    NSArray * imageArray;
}
@property (nonatomic) CGSize pageSize;
-(id)initWithFrame:(CGRect)frame andPageSize:(CGSize)size andContentArray:(NSArray *)array andBackgroundArray:(NSArray *)backGround andTitleArray:(NSArray *)titleArray;
-(void)changeScrollViewAlpha:(CGFloat)alpha;
@end
