//
//  CustomButton.m
//  PrepareForProject
//
//  Created by FaceUI on 13-5-3.
//  Copyright (c) 2013年 faceui. All rights reserved.
//

#import "CustomButton.h"

@implementation CustomButton

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

+(UIView *)initWithFrame:(CGRect)frame backgroundImage:(UIImage *)image andButtonLabel:(NSString *)title target:(id)target selector:(SEL)selector
{
    
    UIView * view = [[UIView alloc]initWithFrame:frame];
    view.backgroundColor = [UIColor colorWithPatternImage:image];
    int i = 0 ;
    int j = 0;
    for (int k = 0; k < title.length; k++) {
        UILabel *lable = [[UILabel alloc]initWithFrame:CGRectMake(27.5 * i, 27.5* j, 27.5, 27.5)];
        lable.textAlignment = NSTextAlignmentCenter;
        lable.backgroundColor = [UIColor clearColor];
        lable.textColor = [UIColor whiteColor];
        lable.font = [UIFont systemFontOfSize:18];
        lable.text = [NSString stringWithFormat:@"%@",[title substringWithRange:NSMakeRange(j*2 + i, 1)]];
        [view addSubview:lable];
        [lable release];
        i++;
        if(i == 2)
        {
            i = 0;
            j++;
        }
        
    }
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.alpha = 1 ;
    button.frame = CGRectMake(0 , 0 , 55, 55);
    [button addTarget:target action:selector forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:button];
    return [view autorelease];
}

+(UIView *)initWithFrame:(CGRect)frame backgroundImage:(UIImage *)image andSubImage:(UIImage *)subImage
{
    UIView * view = [[UIView alloc]initWithFrame:frame];
    view.backgroundColor = [UIColor colorWithPatternImage:image];
    
    UIImageView * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(17.5, 17.5, 30, 30)];
    imageView.image = subImage;
    imageView.center = CGPointMake(frame.size.width/2, frame.size.height/2);
    [view addSubview:imageView];
    [imageView release];
    
    return [view autorelease];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
