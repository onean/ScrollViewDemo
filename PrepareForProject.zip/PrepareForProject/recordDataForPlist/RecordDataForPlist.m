//
//  RecordDataForPlist.m
//  TestProject
//
//  Created by FaceUI on 13-4-15.
//  Copyright (c) 2013年 FaceUI. All rights reserved.
//

#import "RecordDataForPlist.h"

@implementation RecordDataForPlist

+(id)readDataFromPlistWithName:(NSString *)plistName
{
    NSString * documentPath = [self getDocumentPath];
    NSString *filePath = [documentPath stringByAppendingPathComponent:plistName];
    NSDictionary * dic = [[[NSDictionary alloc]initWithContentsOfFile:filePath] autorelease];
    return [dic objectForKey:@"root"];
}
+(void)writeDataFromPlistWithName:(NSString *)plistName andContent:(id)content
{
    NSDictionary * dic = [[NSDictionary alloc]initWithObjectsAndKeys:content ,@"root", nil];
    NSString * documentPath = [self getDocumentPath];
    NSString *filePath = [documentPath stringByAppendingPathComponent:plistName];
    [dic writeToFile:filePath atomically:YES];
    [dic release];
}

+(NSString *)getDocumentPath
{
     return [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
}
@end
