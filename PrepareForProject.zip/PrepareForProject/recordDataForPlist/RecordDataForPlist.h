//
//  RecordDataForPlist.h
//  TestProject
//
//  Created by FaceUI on 13-4-15.
//  Copyright (c) 2013年 FaceUI. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface RecordDataForPlist : NSObject

+(id)readDataFromPlistWithName:(NSString *)plistName;
+(void)writeDataFromPlistWithName:(NSString *)plistName andContent:(id)content;
+(NSString *)getDocumentPath;

@end
