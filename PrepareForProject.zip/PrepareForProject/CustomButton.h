//
//  CustomButton.h
//  PrepareForProject
//
//  Created by FaceUI on 13-5-3.
//  Copyright (c) 2013年 faceui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomButton : UIView
+(UIView *)initWithFrame:(CGRect)frame backgroundImage:(UIImage *)image andButtonLabel:(NSString *)title target:(id)target selector:(SEL)selector;
+(UIView *)initWithFrame:(CGRect)frame backgroundImage:(UIImage *)image andSubImage:(UIImage *) subImage;
@end
