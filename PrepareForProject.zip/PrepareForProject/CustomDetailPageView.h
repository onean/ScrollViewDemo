//
//  CustomDetailPageView.h
//  PrepareForProject
//
//  Created by FaceUI on 13-5-3.
//  Copyright (c) 2013年 faceui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomMapView.h"
#import "SingleMapView.h"
@interface CustomDetailPageView : UIScrollView<UIScrollViewDelegate>
{    UILabel *titleLabel;
}
-(UIView *)initWithTargetLocation:(CLLocationCoordinate2D)coordinate andTitle:(NSString *)title andDetail:(NSString *)detail andBackImage:(UIImage *)image;

-(UIView *)initWithInfoDic:(NSMutableDictionary *)dic;
@end
