//
//  CustomMapView.m
//  RouteTestDemo
//
//  Created by FaceUI on 13-5-2.
//  Copyright (c) 2013年 faceui. All rights reserved.
//

#import "CustomMapView.h"

@implementation CustomMapView

- (id)initWithFrame:(CGRect)frame 
{
    self = [super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame andStartTitle:(NSString *)sTitle andStartSubTitle:(NSString *)sSubTitle andEndTitle:(NSString *)eTitle
    andEndSubTitle:(NSString *) eSubTitle
{
    self = [self initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
    self.mapView = [[[MapView alloc]initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)] autorelease];
    [self addSubview:self.mapView];
    [self.mapView.mapView showsUserLocation];
    //modify account
//    [self.mapView release];
      //modify account
    self.start = [[[Place alloc]init] autorelease];
    self.start.name = sTitle;
    self.start.description = sSubTitle;
      //modify account
    self.end = [[[Place alloc]init] autorelease];
    self.end.name = eSubTitle;
    self.end.description = eTitle;
      //modify account
    self.location = [[[CLLocationManager alloc]init] autorelease];
    self.location.distanceFilter = kCLDistanceFilterNone;
    self.location.desiredAccuracy = kCLLocationAccuracyBest;
    self.location.delegate = self;
    
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(openToUrl) name:ADD_ROUTE object:nil];
    
    
    return self;
}

-(void)openToUrl
{
    UIButton * button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button addTarget:self action:@selector(jumpToWeb:) forControlEvents:UIControlEventTouchUpInside];
    button.frame = CGRectMake(self.frame.size.width - 30, 0, 30, 30);
    [self addSubview:button];
}

-(void)jumpToWeb:(id)sender
{
    
    // open saferi
//    NSString *url = [NSString stringWithFormat:@"http://maps.google.com/maps?saddr=%f,%f&daddr=%f,%f",self.start.latitude,self.start.longitude, self.end.latitude,self.end.longitude];
//    [[UIApplication sharedApplication]openURL:[NSURL URLWithString:[url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
    
    
    //get system version
    
    double version = [[[UIDevice currentDevice] systemVersion] doubleValue];
    
    
    //open maps app
    if (version >= 6.0) {
        
        [MKMapItem openMapsWithItems:[NSArray arrayWithObjects:[[MKMapItem alloc] initWithPlacemark:[[MKPlacemark alloc] initWithCoordinate:CLLocationCoordinate2DMake(self.end.latitude, self.end.longitude) addressDictionary:nil] ], nil]  launchOptions:[NSDictionary dictionaryWithObjectsAndKeys:MKLaunchOptionsDirectionsModeWalking,MKLaunchOptionsDirectionsModeKey, nil]];
        
    }else
    {
        NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"http://maps.apple.com/?saddr=%f,%f&daddr=%f,%f",self.start.latitude,self.start.longitude,self.end.latitude,self.end.longitude]];
        [[UIApplication sharedApplication] openURL:url];
    }

    
}


-(void)showTheRouteToTarget:(CLLocationCoordinate2D )endLocation
{
    self.end.longitude = endLocation.longitude;
    self.end.latitude = endLocation.latitude;
    
//    centerCoordinate = CLLocationCoordinate2DMake(endLocation.latitude, endLocation.longitude);
    
}

-(void)startGetUserLocation
{
        self.currenLocationTimer = [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(getCurrentLocation) userInfo:nil repeats:YES];

}


-(void)getCurrentLocation
{
    [self.location startUpdatingLocation];
}


//设置地图中间显示位置
-(void)centerForCurrent
{
    
//    [self.mapView.mapView setCenterCoordinate:CLLocationCoordinate2DMake(self.start.latitude, self.start.longitude) animated:YES];
    MKCoordinateRegion region;
    //居中显示终点
    region.center = CLLocationCoordinate2DMake(self.end.latitude, self.end.longitude);
    //居中显示七点
//    region.center = CLLocationCoordinate2DMake(self.start.latitude, self.start.longitude);
    //设置当前位置为中心点，并居中显示
//    region.center = CLLocationCoordinate2DMake(centerCoordinate.latitude, centerCoordinate.longitude);
    
    region.span = MKCoordinateSpanMake(0.01, 0.01);
    [self.mapView.mapView setRegion:region animated:YES];
    
}

-(void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    self.start.latitude = self.mapView.mapView.userLocation.coordinate.latitude;
    self.start.longitude = self.mapView.mapView.userLocation.coordinate.longitude;
//    [self.mapView.mapView setCenterCoordinate:self.mapView.mapView.userLocation.coordinate animated:YES];
   
    
    centerCoordinate = self.mapView.mapView.userLocation.coordinate;
    [self centerForCurrent];
    if (self.mapView.mapView.userLocation.coordinate.latitude != 0 && isCreateRoute == 0) {
//        centerCoordinate = self.mapView.mapView.userLocation.coordinate;
        [self.mapView showRouteFrom:self.start to:self.end];
        isCreateRoute = 1;
        [self.location stopUpdatingLocation];
        [self.currenLocationTimer invalidate];
    }
    
}


-(void)stopShowTheRoutes
{
    [self.mapView cancelConnect];
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:ADD_ROUTE object:nil];
    self.currenLocationTimer = nil;
    self.start = nil;
    self.end = nil;
    [super dealloc];
}

@end
