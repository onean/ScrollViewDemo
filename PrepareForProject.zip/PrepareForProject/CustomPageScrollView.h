//
//  CustomPageScrollView.h
//  PrepareForProject
//
//  Created by FaceUI on 13-5-3.
//  Copyright (c) 2013年 faceui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomButton.h"
#import "CustomDetailPageView.h"
@interface CustomPageScrollView : UIScrollView <UIScrollViewDelegate>
{
    NSDictionary *infoDic;
    CGRect currentFrame;
    
    int isAddCancelButton;
}

-(id)initWithFrame:(CGRect)frame withDicInfo:(NSDictionary *)info;


@end
