//
//  CustomScrollView.m
//  ScrollViewTestDemo
//
//  Created by FaceUI on 13-4-23.
//  Copyright (c) 2013年 faceui. All rights reserved.
//

#import "CustomScrollView.h"

@implementation CustomScrollView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
-(id)initWithFrame:(CGRect)frame andPageSize:(CGSize)size andContentArray:(NSArray *)array andBackgroundArray:(NSArray *)backGround andTitleArray:(NSArray *)titleArray
{
    self = [self initWithFrame:frame];
    array = [array retain];
    imageArray = [[NSArray alloc] initWithArray:backGround];
    self.pageSize = size;
    [self setShowsHorizontalScrollIndicator:NO];
    [self setShowsVerticalScrollIndicator:NO];
    self.contentSize = CGSizeMake(size.width*array.count, size.height);
    self.delegate = self;
    [self setPagingEnabled:YES];
    for (int i = 0 ;i < array.count ; i++ ) {
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(120+i*size.width, 8, 80, 18)];
        label.textColor = [UIColor whiteColor];
        label.font = [UIFont systemFontOfSize:18];
        label.textAlignment = NSTextAlignmentCenter;
        label.backgroundColor = [UIColor clearColor];
        label.text = [NSString stringWithFormat:@"%@",[titleArray objectAtIndex:i]];
        
        
        UIScrollView * scroll = [array objectAtIndex:i];
        scroll.delegate = self;
        scroll.frame = CGRectMake(i*size.width, 0, size.width, size.height);
        
        UIScrollView * imageScroll = [[UIScrollView alloc]initWithFrame:CGRectMake(i*size.width, 0, size.width, size.height)];
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, size.width, size.height)];
        imageView.image = [UIImage imageNamed:[backGround objectAtIndex:i]];
        imageScroll.tag = 100 + i;
        imageScroll.delegate = self;
        [imageScroll addSubview:imageView];
        [imageView release];
        [self addSubview:imageScroll];
        
        UIView *alphaView = [[UIView alloc]initWithFrame:scroll.frame];
        alphaView.backgroundColor = [UIColor blackColor];
        alphaView.tag = 1000 + i;
        alphaView.alpha = 0;
        [self addSubview:alphaView];
        
//        UIImageView *alphaView = [[UIImageView alloc]initWithFrame:scroll.frame];
//        alphaView.backgroundColor = [UIColor clearColor];
//        alphaView.tag = 1000 + i;
//        [self addSubview:alphaView];
        
        [self addSubview:scroll];
        [self addSubview:label];
        [label release];
        [alphaView release];
        [scroll release];
    }
    return self;
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    int index = scrollView.contentOffset.x/self.pageSize.width;
    
    
        if (index > -1 && scrollView.contentSize.width/self.pageSize.width >= index) {
            for (UIView * v in scrollView.subviews) {
                UIScrollView * scroll = (UIScrollView *)v;
                for (int i = 0; i < scrollView.contentSize.width/self.pageSize.width; i++) {
                    if (i + 100 == scroll.tag) {
                        if (scrollView.contentOffset.x - scroll.frame.origin.x >= -self.pageSize.width && scrollView.contentOffset.x - scroll.frame.origin.x <= 0) {
                            
                            scroll.contentOffset =CGPointMake(-(scrollView.contentOffset.x - scroll.frame.origin.x)/2, 0);
                        }else if (scrollView.contentOffset.x - scroll.frame.origin.x < self.pageSize.width && scrollView.contentOffset.x - scroll.frame.origin.x >0)
                        {
                            scroll.contentOffset =CGPointMake(-(scrollView.contentOffset.x - scroll.frame.origin.x)/2, 0);
                        }
                    }
                }
                
            }
        }
        if (scrollView.contentOffset.y > 0 && scrollView.contentOffset.y < 350) {
            [self changeScrollViewAlpha:scrollView.contentOffset.y/500];
        }

}



-(void)changeScrollViewAlpha:(CGFloat)alpha
{
    int index = self.contentOffset.x/self.pageSize.width;
    
    for (UIView * v in self.subviews){
        if (v.tag == 1000 + index) {
            
//            ((UIImageView *)v).image = [[UIImage imageNamed:[imageArray objectAtIndex:index]] boxblurImageWithBlur:alpha];
            
            v.alpha = alpha;
        }
    }
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
