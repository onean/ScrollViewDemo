//
//  CustomMapView.h
//  RouteTestDemo
//
//  Created by FaceUI on 13-5-2.
//  Copyright (c) 2013年 faceui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MapView.h"
#import "Place.h"
#import <CoreLocation/CoreLocation.h>



@interface CustomMapView : UIView<CLLocationManagerDelegate,MKMapViewDelegate>
{
    int isCreateRoute;
    CLLocationCoordinate2D centerCoordinate;
}
@property (retain, nonatomic) MapView *mapView;
@property (retain, nonatomic) Place *start;
@property (retain, nonatomic) Place *end;
@property (retain, nonatomic) CLLocationManager *location;
@property (retain, nonatomic) NSTimer *currenLocationTimer;

-(id)initWithFrame:(CGRect)frame andStartTitle:(NSString *)sTitle andStartSubTitle:(NSString *)sSubTitle andEndTitle:(NSString *)eTitle andEndSubTitle:(NSString *) eSubTitle;

//fire the timer to get current location
-(void)startGetUserLocation;

//put current to center of screen
-(void)centerForCurrent;


//draw the route from current location to target
-(void)showTheRouteToTarget:(CLLocationCoordinate2D )endLocation;
-(void) stopShowTheRoutes;
@end
