//
//  CustomDetailPageView.m
//  PrepareForProject
//
//  Created by FaceUI on 13-5-3.
//  Copyright (c) 2013年 faceui. All rights reserved.
//

#import "CustomDetailPageView.h"

static CustomDetailPageView * custom = nil;
@implementation CustomDetailPageView



- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(UIView *)initWithTargetLocation:(CLLocationCoordinate2D)coordinate andTitle:(NSString *)title andDetail:(NSString *)detail andBackImage:(UIImage *)image
{
    
    self.delegate = self;
    
    self = [self initWithFrame:CGRectMake(0,20, [[UIScreen mainScreen] bounds].size.width, [[UIScreen mainScreen] bounds].size.height - 20)];
    
    [self setShowsHorizontalScrollIndicator:NO];
    [self setShowsVerticalScrollIndicator:NO];
    
    self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"sub_bg.png"]];
   
    
    titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(120, 10, 80, 18)];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.font = [UIFont systemFontOfSize:18];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.textColor = [UIColor whiteColor];
    [self addSubview:titleLabel];
    [titleLabel release];
    
    
    titleLabel.text = title;
    
    UIImageView * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(11, 42, 298, 208)];
    imageView.image = image;
    [self addSubview:imageView];
    [imageView release];
    
    UITextView * detailTextView = [[UITextView alloc]initWithFrame:CGRectMake(11, 235, 298, 44)];
    detailTextView.backgroundColor = [UIColor clearColor];
    detailTextView.textColor = [UIColor whiteColor];
    detailTextView.font = [UIFont systemFontOfSize:15];
    detailTextView.text = detail;
    [detailTextView setEditable:NO];
    [self addSubview:detailTextView];
    [detailTextView release];
    
    
    SingleMapView *single = [SingleMapView initMapViewWithFrame:CGRectMake(11, 280, 298, 280) WithTargetLocation:coordinate andStartTitle:@"start" andStartSubTitle:@"我的位置" andEndTitle:@"目的地" andEndSubTitle:title];
    
    [self addSubview:single];
//    [single release];
    
//    CustomMapView *mapview = [[CustomMapView alloc]initWithFrame:CGRectMake(11, 280, 298, 280) andStartTitle:@"我的位置" andStartSubTitle:@"当前位置" andEndTitle:@"牛肉拉面" andEndSubTitle:@"最好吃的牛肉拉面"];
//    [mapview startGetUserLocation];
//    [mapview showTheRouteToTarget:coordinate];
//    [mapview centerForCurrent];
//    [self addSubview:mapview];
//    [mapview release];
    
    
    self.contentSize = CGSizeMake(320, 580);
    
    return self;
}


//传入数据字典根据键值传值
-(UIView *)initWithInfoDic:(NSMutableDictionary *)dic
{
    NSLog(@"%@",dic);
    CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake([[dic objectForKey:@"latitude"] floatValue], [[dic objectForKey:@"longitude"] floatValue]);
    
    self.delegate = self;
    
    self = [self initWithFrame:CGRectMake(0,20, [[UIScreen mainScreen] bounds].size.width, [[UIScreen mainScreen] bounds].size.height - 20)];
    
    [self setShowsHorizontalScrollIndicator:NO];
    [self setShowsVerticalScrollIndicator:NO];
    
    self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"sub_bg.png"]];
    
    
    titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(120, 10, 80, 18)];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.font = [UIFont systemFontOfSize:18];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.text = [dic objectForKey:@"title"];
    [self addSubview:titleLabel];
    [titleLabel release];
    
    
    
    
    
    
    UIImageView * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(11, 42, 298, 208)];
    imageView.image = [dic objectForKey:@"image"];
    [self addSubview:imageView];
    [imageView release];
    
    
    UITextView * detailTextView = [[UITextView alloc]initWithFrame:CGRectMake(11, 235, 298, 44)];
    detailTextView.backgroundColor = [UIColor clearColor];
    detailTextView.textColor = [UIColor whiteColor];
    detailTextView.font = [UIFont systemFontOfSize:15];
    detailTextView.text = [dic objectForKey:@"detail"];
    [detailTextView setEditable:NO];
    [self addSubview:detailTextView];
    [detailTextView release];
    
    
    CustomMapView *mapview = [[CustomMapView alloc]initWithFrame:CGRectMake(11, 280, 298, 280) andStartTitle:[dic objectForKey:@"start"] andStartSubTitle:[dic objectForKey:@"start_detail"] andEndTitle:[dic objectForKey:@"target"] andEndSubTitle:[dic objectForKey:@"target_detail"]];
    [mapview startGetUserLocation];
    [mapview showTheRouteToTarget:coordinate];
    [mapview centerForCurrent];
    [self addSubview:mapview];
    [mapview release];
    self.contentSize = CGSizeMake(320, 580);
    
    
    return self;
}


-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
//    titleLabel.frame = CGRectMake(titleLabel.frame.origin.x, scrollView.contentOffset.y + 10, titleLabel.frame.size.width, titleLabel.frame.size.height);
}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
