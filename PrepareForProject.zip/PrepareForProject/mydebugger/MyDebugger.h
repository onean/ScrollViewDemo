//
//  MyDebugger.h
//  player
//
//  Created by FaceUI on 13-4-11.
//  Copyright (c) 2013年 FaceUI. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyDebugger : NSObject

+(void)nslogObject:(id)object;
+(void)nslogFloat:(float)f;
+(void)nslogInt:(int)i;
+(void)nslogString:(NSString *)string;
@end
