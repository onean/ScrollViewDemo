//
//  SingleMapView.h
//  PrepareForProject
//
//  Created by FaceUI on 13-5-14.
//  Copyright (c) 2013年 faceui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CustomMapView.h"
@interface SingleMapView : UIView
+(id)initMapViewWithFrame:(CGRect)frame WithTargetLocation:(CLLocationCoordinate2D)coordinate andStartTitle:(NSString *)sTitle andStartSubTitle:(NSString *)sSubTitle andEndTitle:(NSString *)eTitle andEndSubTitle:(NSString *) eSubTitle;
@end
