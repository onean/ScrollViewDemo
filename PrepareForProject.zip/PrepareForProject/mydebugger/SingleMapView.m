//
//  SingleMapView.m
//  PrepareForProject
//
//  Created by FaceUI on 13-5-14.
//  Copyright (c) 2013年 faceui. All rights reserved.
//

#import "SingleMapView.h"
static SingleMapView * singleMapView = nil;
@implementation SingleMapView

+(id)initMapViewWithFrame:(CGRect)frame WithTargetLocation:(CLLocationCoordinate2D)coordinate andStartTitle:(NSString *)sTitle andStartSubTitle:(NSString *)sSubTitle andEndTitle:(NSString *)eTitle andEndSubTitle:(NSString *)eSubTitle
{
    if (singleMapView == nil ) {
        singleMapView = [[SingleMapView alloc]initWithFrame:frame];
          CustomMapView * view = [[CustomMapView alloc]initWithFrame:frame andStartTitle:sTitle andStartSubTitle:sSubTitle andEndTitle:eTitle andEndSubTitle:eSubTitle];
        
        [view startGetUserLocation];
        [view showTheRouteToTarget:coordinate];
        [view centerForCurrent];

        [singleMapView addSubview:view];
//        [view release];
    }
    else
    {
        for (UIView * v in singleMapView.subviews) {
            [v removeFromSuperview];
        }
        CustomMapView * view = [[CustomMapView alloc]initWithFrame:frame andStartTitle:sTitle andStartSubTitle:sSubTitle andEndTitle:eTitle andEndSubTitle:eSubTitle];        
        [view startGetUserLocation];
        [view showTheRouteToTarget:coordinate];
        [view centerForCurrent];
        
        [singleMapView addSubview:view];
//        [view release];

    }
    return singleMapView;
}

@end
