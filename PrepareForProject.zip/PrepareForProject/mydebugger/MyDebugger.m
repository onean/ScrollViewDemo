//
//  MyDebugger.m
//  player
//
//  Created by FaceUI on 13-4-11.
//  Copyright (c) 2013年 FaceUI. All rights reserved.
//

#import "MyDebugger.h"

@implementation MyDebugger
+(void)nslogObject:(id)object
{
    NSLog(@"\n------------------------------\n%@\n------------------------------",object);
}
+(void)nslogFloat:(float)f
{
    
    NSLog(@"\n------------------------------\n%f\n------------------------------",f);
}
+(void)nslogInt:(int)i
{
    NSLog(@"\n------------------------------\n%d\n------------------------------",i);
}
+(void)nslogString:(NSString *)string
{
    NSLog(@"\n------------------------------\n%@\n------------------------------",string);
}
@end
