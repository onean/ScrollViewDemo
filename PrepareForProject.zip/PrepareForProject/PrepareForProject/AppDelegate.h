//
//  AppDelegate.h
//  PrepareForProject
//
//  Created by FaceUI on 13-5-2.
//  Copyright (c) 2013年 faceui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RootViewController.h"
#import "ProjectViewController.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
